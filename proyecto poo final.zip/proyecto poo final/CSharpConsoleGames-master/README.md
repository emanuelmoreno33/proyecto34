C# Console Games
================

Source code of four C# console games with video explanation in Bulgarian

* Cars: http://www.youtube.com/watch?v=bQexyufgclY
* PingPong: http://www.youtube.com/watch?v=DmkqnjsNKZM
* Snake: http://www.youtube.com/watch?v=dXng0W0R_Ks
* Tron: http://www.youtube.com/watch?v=yccxWRsQBB0
* Tetris: https://www.youtube.com/watch?v=0-WOuN0qqI0
