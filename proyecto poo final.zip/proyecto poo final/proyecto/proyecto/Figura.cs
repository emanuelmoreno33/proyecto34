﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proyecto
{
   abstract class Figura
    {
       public int x, y;
        public int largo, ancho, grosor;
        public Color pluma, Brocha;
        public int x1, x2, y1, y2;

        public Figura(int x, int y)
        {
            this.x = x;
            this.y = y;
            ancho = 20;
            largo = 20;
            grosor = 2;
            pluma = Color.Blue;
            Brocha = Color.Red;
        }

       public Figura (int x1, int x2, int y1, int y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            ancho = 20;
            largo = 20;
            grosor = 2;
            pluma = Color.Blue;
            Brocha = Color.Red;
        }

        public abstract void Dibujar(Graphics g);

         public abstract void CambiarPluma(Color pluma);
       // public abstract void CambiarBrocha();
       // public abstract void CambiarDimensiones();
       //public abstract void CambiarGrosor();

    }
}
