﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proyecto
{
    class Circulo:Figura
    {
        public Circulo(int x, int y):base (x,y)
        {
            this.x = x;
            this.y = y;
        }

        public override void Dibujar(Graphics g)
        {
            g.DrawEllipse(new Pen(pluma, grosor), x, y, ancho, largo);
            g.FillEllipse(new SolidBrush(Brocha), x, y, ancho, largo);
           
        }
    }
}
