﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proyecto
{
    class Pentagono:Figura
    {
        public Pentagono(int x, int y):base (x,y)
        {
            this.x = x;
            this.y = y;

        }

        public override void Dibujar(Graphics g)
        {
            Point[] pentagonopuntos = {new Point(x-5,y+10), new Point(x - 10, y),  new Point(x, y - 10),new Point(x + 10, y), new Point(x+5,y+10)};
            g.DrawPolygon(new Pen(pluma,grosor), pentagonopuntos);
            g.FillPolygon(new SolidBrush(Brocha), pentagonopuntos);

           
        }
    }
}
