﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proyecto
{
    class Triangulo:Figura
    {
        public Triangulo(int x, int y):base (x,y)
        {
            this.x = x;
            this.y = y;
            
        }

        public override void Dibujar(Graphics g)
        {
            Point[] triangulopuntos = { new Point(x - 20, y), new Point(x + 20, y), new Point(x, y - 20) };
            g.DrawPolygon(new Pen(pluma,grosor), triangulopuntos);
            g.FillPolygon(new SolidBrush(Brocha), triangulopuntos);
        }
    }
}
