﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto
{
    public partial class Propiedades : Form
    {
        public Color colorcambiado;

        public Propiedades()
        {
            InitializeComponent();
            textBox1.Text = Convert.ToString(hScrollBar1.Value);
            textBox2.Text = Convert.ToString(hScrollBar2.Value);
            textBox3.Text = Convert.ToString(hScrollBar3.Value);            
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            textBox1.Text = Convert.ToString(hScrollBar1.Value);
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            textBox2.Text = Convert.ToString(hScrollBar2.Value);
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            textBox3.Text = Convert.ToString(hScrollBar3.Value);
        }

        private void color_contorno_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
              colorcambiado = colorDialog1.Color;
              color_contorno.BackColor = colorcambiado;
            }
        }
    }
}
