﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto
{
    public partial class Form1 : Form
    {
      //  enum TipoFigura { Rectangulo, Circulo, Triangulo};


        private List<Figura> figuras;
        public int largo, ancho, grosor;
        public Color pluma, brocha;

        public Form1()
        {
            InitializeComponent();
            figuras = new List<Figura>();
            circuloizq.ForeColor = Color.Red;
            cuadradoder.ForeColor = Color.Red;
        }


        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                Cuadro cuadro = new Cuadro(e.X, e.Y);
                Graphics g = CreateGraphics();
                cuadro.Dibujar(g);
                figuras.Add(cuadro);
                cuadro.grosor = grosor;
                cuadro.pluma = pluma;

            }
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                Circulo circulo = new Circulo(e.X, e.Y);
                Graphics g = CreateGraphics();
                circulo.Dibujar(g);
                figuras.Add(circulo);

                //Triangulo triangulo = new Triangulo(e.X, e.Y);
                //Graphics g = CreateGraphics();
                //triangulo.Dibujar(g);
                //figuras.Add(triangulo);

                //Pentagono pentagono = new Pentagono(e.X, e.Y);
                //Graphics g = CreateGraphics();
                //pentagono.Dibujar(g);
                //figuras.Add(pentagono);

                //Lineavertical lineaver = new Lineavertical(e.X, e.X,e.Y,e.Y+50);
                //Graphics g = CreateGraphics();
                //lineaver.Dibujar(g);
                //figuras.Add(lineaver);

               // lineahorizontal lineahor = new lineahorizontal(e.X, e.X+50, e.Y, e.Y);
               //// Graphics g = CreateGraphics();
               // lineahor.Dibujar(g);
               // figuras.Add(lineaver);


            }

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foreach (Figura c in figuras)
            {
                c.Dibujar(CreateGraphics());
              
            }
        }

        private void cambiarPropiedadesmenu_Click(object sender, EventArgs e)
        {
            Propiedades frm = new Propiedades();
            if (frm.ShowDialog() == DialogResult.OK)
            {
                largo = frm.hScrollBar1.Value;
                ancho = frm.hScrollBar2.Value;
                grosor = frm.hScrollBar3.Value;
                pluma = frm.colorcambiado;
            }
        }

        private void borrarDibujosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Invalidate();
            figuras.Clear();
        }
    }
}
