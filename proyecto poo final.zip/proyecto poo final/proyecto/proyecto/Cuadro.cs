﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proyecto
{
    class Cuadro:Figura
    {        
        public Cuadro(int x, int y):base (x,y)
        {
            this.x = x;
            this.y = y;
        }

        public override void Dibujar(Graphics g)
        {
            g.DrawRectangle(new Pen(pluma, grosor), x, y, ancho, largo);
            g.FillRectangle(new SolidBrush(Brocha), x, y, ancho, largo);
        }

        public override void CambiarPluma(Color c)
        {
            pluma = c;
        }

    }
}