﻿namespace proyecto
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cambiar_formamenu = new System.Windows.Forms.ToolStripMenuItem();
            this.botonizq = new System.Windows.Forms.ToolStripMenuItem();
            this.circuloizq = new System.Windows.Forms.ToolStripMenuItem();
            this.cuadradoizq = new System.Windows.Forms.ToolStripMenuItem();
            this.pentagonoizq = new System.Windows.Forms.ToolStripMenuItem();
            this.lineaizq = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.verdadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trianguloizq = new System.Windows.Forms.ToolStripMenuItem();
            this.botonder = new System.Windows.Forms.ToolStripMenuItem();
            this.circuloder = new System.Windows.Forms.ToolStripMenuItem();
            this.cuadradoder = new System.Windows.Forms.ToolStripMenuItem();
            this.pentagonoder = new System.Windows.Forms.ToolStripMenuItem();
            this.lineader = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trianguloder = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiarPropiedadesmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarDibujosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cambiar_formamenu,
            this.cambiarPropiedadesmenu,
            this.borrarDibujosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(806, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cambiar_formamenu
            // 
            this.cambiar_formamenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.botonizq,
            this.botonder});
            this.cambiar_formamenu.Name = "cambiar_formamenu";
            this.cambiar_formamenu.Size = new System.Drawing.Size(99, 20);
            this.cambiar_formamenu.Text = "Cambiar forma";
            // 
            // botonizq
            // 
            this.botonizq.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.circuloizq,
            this.cuadradoizq,
            this.pentagonoizq,
            this.lineaizq,
            this.trianguloizq});
            this.botonizq.Name = "botonizq";
            this.botonizq.Size = new System.Drawing.Size(158, 22);
            this.botonizq.Text = "Boton izquierdo";
            // 
            // circuloizq
            // 
            this.circuloizq.Name = "circuloizq";
            this.circuloizq.Size = new System.Drawing.Size(132, 22);
            this.circuloizq.Text = "Circulo";
            // 
            // cuadradoizq
            // 
            this.cuadradoizq.Name = "cuadradoizq";
            this.cuadradoizq.Size = new System.Drawing.Size(132, 22);
            this.cuadradoizq.Text = "Cuadrado";
            // 
            // pentagonoizq
            // 
            this.pentagonoizq.Name = "pentagonoizq";
            this.pentagonoizq.Size = new System.Drawing.Size(132, 22);
            this.pentagonoizq.Text = "Pentagono";
            // 
            // lineaizq
            // 
            this.lineaizq.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.horizontalToolStripMenuItem1,
            this.verdadToolStripMenuItem});
            this.lineaizq.Name = "lineaizq";
            this.lineaizq.Size = new System.Drawing.Size(132, 22);
            this.lineaizq.Text = "Linea recta";
            // 
            // horizontalToolStripMenuItem1
            // 
            this.horizontalToolStripMenuItem1.Name = "horizontalToolStripMenuItem1";
            this.horizontalToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.horizontalToolStripMenuItem1.Text = "Horizontal";
            // 
            // verdadToolStripMenuItem
            // 
            this.verdadToolStripMenuItem.Name = "verdadToolStripMenuItem";
            this.verdadToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.verdadToolStripMenuItem.Text = "Verdad";
            // 
            // trianguloizq
            // 
            this.trianguloizq.Name = "trianguloizq";
            this.trianguloizq.Size = new System.Drawing.Size(132, 22);
            this.trianguloizq.Text = "Triangulo";
            // 
            // botonder
            // 
            this.botonder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.circuloder,
            this.cuadradoder,
            this.pentagonoder,
            this.lineader,
            this.trianguloder});
            this.botonder.Name = "botonder";
            this.botonder.Size = new System.Drawing.Size(158, 22);
            this.botonder.Text = "Boton derecho";
            // 
            // circuloder
            // 
            this.circuloder.Name = "circuloder";
            this.circuloder.Size = new System.Drawing.Size(132, 22);
            this.circuloder.Text = "Circulo";
            // 
            // cuadradoder
            // 
            this.cuadradoder.Name = "cuadradoder";
            this.cuadradoder.Size = new System.Drawing.Size(132, 22);
            this.cuadradoder.Text = "Cuadrado";
            // 
            // pentagonoder
            // 
            this.pentagonoder.Name = "pentagonoder";
            this.pentagonoder.Size = new System.Drawing.Size(132, 22);
            this.pentagonoder.Text = "Pentagono";
            // 
            // lineader
            // 
            this.lineader.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.horizontalToolStripMenuItem,
            this.verticalToolStripMenuItem});
            this.lineader.Name = "lineader";
            this.lineader.Size = new System.Drawing.Size(132, 22);
            this.lineader.Text = "Linea recta";
            // 
            // horizontalToolStripMenuItem
            // 
            this.horizontalToolStripMenuItem.Name = "horizontalToolStripMenuItem";
            this.horizontalToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.horizontalToolStripMenuItem.Text = "Horizontal";
            // 
            // verticalToolStripMenuItem
            // 
            this.verticalToolStripMenuItem.Name = "verticalToolStripMenuItem";
            this.verticalToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.verticalToolStripMenuItem.Text = "Vertical";
            // 
            // trianguloder
            // 
            this.trianguloder.Name = "trianguloder";
            this.trianguloder.Size = new System.Drawing.Size(132, 22);
            this.trianguloder.Text = "Triangulo";
            // 
            // cambiarPropiedadesmenu
            // 
            this.cambiarPropiedadesmenu.Name = "cambiarPropiedadesmenu";
            this.cambiarPropiedadesmenu.Size = new System.Drawing.Size(132, 20);
            this.cambiarPropiedadesmenu.Text = "Cambiar propiedades";
            this.cambiarPropiedadesmenu.Click += new System.EventHandler(this.cambiarPropiedadesmenu_Click);
            // 
            // borrarDibujosToolStripMenuItem
            // 
            this.borrarDibujosToolStripMenuItem.Name = "borrarDibujosToolStripMenuItem";
            this.borrarDibujosToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.borrarDibujosToolStripMenuItem.Text = "Borrar Dibujos";
            this.borrarDibujosToolStripMenuItem.Click += new System.EventHandler(this.borrarDibujosToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 441);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cambiar_formamenu;
        private System.Windows.Forms.ToolStripMenuItem botonizq;
        private System.Windows.Forms.ToolStripMenuItem botonder;
        private System.Windows.Forms.ToolStripMenuItem circuloizq;
        private System.Windows.Forms.ToolStripMenuItem cuadradoizq;
        private System.Windows.Forms.ToolStripMenuItem pentagonoizq;
        private System.Windows.Forms.ToolStripMenuItem lineaizq;
        private System.Windows.Forms.ToolStripMenuItem trianguloizq;
        private System.Windows.Forms.ToolStripMenuItem circuloder;
        private System.Windows.Forms.ToolStripMenuItem cuadradoder;
        private System.Windows.Forms.ToolStripMenuItem pentagonoder;
        private System.Windows.Forms.ToolStripMenuItem lineader;
        private System.Windows.Forms.ToolStripMenuItem trianguloder;
        private System.Windows.Forms.ToolStripMenuItem cambiarPropiedadesmenu;
        private System.Windows.Forms.ToolStripMenuItem borrarDibujosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horizontalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verdadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verticalToolStripMenuItem;
    }
}

